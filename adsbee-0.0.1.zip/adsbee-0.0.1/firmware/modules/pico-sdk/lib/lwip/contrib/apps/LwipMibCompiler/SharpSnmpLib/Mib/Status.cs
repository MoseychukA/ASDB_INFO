﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lextm.SharpSnmpLib.Mib
{
    public enum Status
    {
        current,
        deprecated,
        obsolete,
        mandatory,
        optional
    }

}
