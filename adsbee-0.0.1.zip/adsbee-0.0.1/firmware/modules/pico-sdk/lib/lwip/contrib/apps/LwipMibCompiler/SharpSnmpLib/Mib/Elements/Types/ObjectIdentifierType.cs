﻿
namespace Lextm.SharpSnmpLib.Mib.Elements.Types
{
    public class ObjectIdentifierType : BaseType
    {
        public ObjectIdentifierType(IModule module, string name, ISymbolEnumerator symbols)
            : base(module, name)
        {
        }
    }
}
