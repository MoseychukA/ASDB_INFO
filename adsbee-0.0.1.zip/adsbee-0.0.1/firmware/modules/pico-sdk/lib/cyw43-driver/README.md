CYW43xx WiFi/BT SoC driver
==========================

This is a driver for the CYW43xx WiFi/BT SoC.

This cyw43-driver is free only for non-commercial use (see LICENSE in this directory).
This cyw43-driver is also available for use with Raspberry Pi Ltd semiconductor
devices under different terms (see LICENSE.RP in this directory).

For commercial licensing options please email contact@georgerobotics.com.au.
